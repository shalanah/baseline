The font "Baseline Em" was created by Shalanah Dawson in 2017 using FontForge.
This font may be used and altered on any medium without attribution or permission.
